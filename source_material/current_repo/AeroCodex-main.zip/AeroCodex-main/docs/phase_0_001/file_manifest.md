# Phase 0.001 File Manifest

This manifest lists repository files with SHA256 hashes. It omits `docs/phase_0_001/file_manifest.md` and `docs/phase_0_001/file_inventory.csv` to avoid self-referential hash churn.

Deployment note: this manifest was regenerated after deployment-agent rustfmt, Clippy, and whitespace normalization fixes.

Total files hashed: 107

| Path | Size bytes | SHA256 |
|---|---:|---|
| `.github/workflows/ci.yml` | 527 | `0728678207bb395a54a44563b84f82d18c96d053edcbe256fd82fe3fdd88450f` |
| `.gitignore` | 36 | `86fcc2e0bbb0e0e9f530e72628a6d885a5fc5774de0028cb437930d94ce74946` |
| `ARTIFACT_MANIFEST.md` | 1073 | `57f849789a77f28d9ab84518591c9951fc5389cf05342b5652367fb4403ce599` |
| `Cargo.toml` | 728 | `5a46be75aef860e0fe8a8bc6e5f6754279ad5be9f9029e6ed63b3bec75246d64` |
| `LICENSE` | 188 | `43dcbee8e82338ad564c76cdca10d4cbea7db75a9f9cd18c21a654e2b3ffd510` |
| `LICENSE-APACHE` | 11324 | `50e6751797c50dedd75ef1b8a0d9e42f5f8472e9fbce91f34718e9f97b0c780a` |
| `LICENSE-MIT` | 1079 | `aa111e2f12031a6b09bcd76d7ba2d884e488fe0dfba232d5018184b6ac1f7e64` |
| `NOTICE` | 374 | `3cbd4b5b1fb0fb13d84420f72e755dd890b4f5391dfc57b0c6318ca3cd0dd316` |
| `README.md` | 4509 | `7d03d5233ec46e7e54a6b026b1a7bd4c4177f1fe2a865c73cc62af85b407c6a1` |
| `archive/prompts/Pasted markdown.md` | 30581 | `359569671ccfff94f21ab1c46d3abb751781679fd1253e0433cda8289645ff8c` |
| `crates/aero-codex-aerodynamics/Cargo.toml` | 328 | `278105c978589798caaa1a7babf32111d2c9a863065173c270bc72b058d7ed69` |
| `crates/aero-codex-aerodynamics/src/lib.rs` | 13901 | `dee50db83a24a308a3fb6b0f50390ebe9985e732b45d0429a0d93befe7ff44ff` |
| `crates/aero-codex-astrodynamics/Cargo.toml` | 390 | `38f36a7112039320b2332b7df5bdd5fbbd9967afd0a233b2f6fd22ddbab99191` |
| `crates/aero-codex-astrodynamics/src/lib.rs` | 32605 | `e1b281472f98105d7f1ff2577590885848da3b8b0acbca6bb996b155388efca1` |
| `crates/aero-codex-atmosphere/Cargo.toml` | 384 | `f56aa38bc0e50b66d9c01f0631b7700c043e1658cf1c20aae56890cf54ecce31` |
| `crates/aero-codex-atmosphere/src/lib.rs` | 11898 | `8df8bfc474dc9b28335e68ee0028563312471774c3fae7e8403daa214b07a6b1` |
| `crates/aero-codex-constants/Cargo.toml` | 273 | `c57f816baff114b0f8f6bde0bc6d08aed0d387e2ea973e86188d0cd56c2d44b9` |
| `crates/aero-codex-constants/src/lib.rs` | 11711 | `87fb8651f41f7206d6971b10783bf8d6c74a98384e9a7c9ccda375aff8860c3e` |
| `crates/aero-codex-core/Cargo.toml` | 263 | `8f5579d3457fd6e8303e57de8fef739316915ea6a7e88035bbe1353faad3c19b` |
| `crates/aero-codex-core/src/error.rs` | 4389 | `32b53fe09f4a286be5eb518312083b898e80f6fb3eccfe99b9d230fd8d214326` |
| `crates/aero-codex-core/src/lib.rs` | 5655 | `48dac5594d8eea868df1f762de907ddb9f6527c7998a958c833a07428be8e390` |
| `crates/aero-codex-core/src/result.rs` | 8328 | `17207d255efaf6499bdf35dddefec3d214af3bbe5d32afa7a8fa71dfa5808b7b` |
| `crates/aero-codex-core/src/units.rs` | 8762 | `9fe4fff26dea0701131d3909865cf4b6122fb8d99edd9e84e6e804a42174c14c` |
| `crates/aero-codex-core/src/validation.rs` | 1944 | `61182d3ecb4285bc04a2a5f03d3d31d3c7d84566c743b96abb700a3ec94b21b8` |
| `crates/aero-codex-flight-dynamics/Cargo.toml` | 334 | `075b60e1288900f37354c3dda4a2ec52b52cc6359be53d851b55486be9b1dc5f` |
| `crates/aero-codex-flight-dynamics/src/lib.rs` | 19136 | `d33aeec0da88990370ef5e7f03f25f0c014ea1b35c6e2e867e0967791978885e` |
| `crates/aero-codex-gas-dynamics/Cargo.toml` | 388 | `16e4604c19aba7ded01dda4d8f38e82183abf9d649a8b883d61576f908496cc8` |
| `crates/aero-codex-gas-dynamics/src/lib.rs` | 52851 | `892a9abd7737053da6bc0d2d9da77e9236d1853a2cd8ed3749ac689d11275f9a` |
| `crates/aero-codex-heat-transfer/Cargo.toml` | 390 | `8faafa0b3c48cb1656f557d274aac3b6c4203adb752537f2c08464a236d3bfe8` |
| `crates/aero-codex-heat-transfer/src/lib.rs` | 15421 | `c75eb3b5c9e1288cdd8a4c6186029bc14426dfee91f61059ff3b785be02b2663` |
| `crates/aero-codex-life-support/Cargo.toml` | 328 | `d555ca7a2d782ae0e0925094b135dbe487e8e19695d68b7859521b7ce838451e` |
| `crates/aero-codex-life-support/src/lib.rs` | 21288 | `4a538d892231e1670d0424bbc18ce5b9525e955eccf314d444513208d65663b2` |
| `crates/aero-codex-propulsion/Cargo.toml` | 324 | `cdcdc065655e749fbd9d9ab4e795e9085b9f86d60b65cfae09ed98dbd1f9740c` |
| `crates/aero-codex-propulsion/src/lib.rs` | 18428 | `32503fd098851eb7c29b0bc67e17f0f30fc2055ef8710552786f2d34622b60bc` |
| `crates/aero-codex-structures/Cargo.toml` | 324 | `c28b30173c53ae9d7b26c1a5120d70d38f5e79b6e28e679caf7ff3d19e490f6b` |
| `crates/aero-codex-structures/src/lib.rs` | 16367 | `e300e50d6b14a8ea04e41adc54a0d89c7e7d10a105864f626e5dc96f230ba8d7` |
| `crates/aero-codex-thermo/Cargo.toml` | 376 | `a067cc5869df4befb62c5bcb283245760d4fa57253841f0d265d19078ed837a0` |
| `crates/aero-codex-thermo/src/lib.rs` | 13175 | `f9935efbafdf65d5ca06cb4fc0cb68ef417254579d2929c9f1ba9f6280c7e868` |
| `docs/deployment/deploy_agent_prompt_v0_001_microtasks_001_020.md` | 4129 | `22272c65bddaf68e5edecc350637edc78c6906b9e402ca5f56d5b55d7b58a398` |
| `docs/index.md` | 3611 | `d0d843002706c7dfd5b17b38f58371d3bcd475f891d57ba22fc8e072876c0dd4` |
| `docs/phase_0_001/api_summary.md` | 7559 | `af67921792105bd2c7b5fe8a8190300a0448b912adafdcc69825b0880bfe8906` |
| `docs/phase_0_001/final_microtasks_001_020_report.md` | 12103 | `f925907248a00b9dfdacce0089dbb0fcd8f7191e73c56ca4d356f900c6551578` |
| `docs/phase_0_001/microtask_002_versioning_review.md` | 1312 | `bccd96f0d354f543c4ad03b05088bd87723263682c95f55fcd03baf5d8649c94` |
| `docs/phase_0_001/microtask_003_core_result_error_verification.md` | 4577 | `7c4707509ff9bb49dc65fecb809385cfb7f31cb9d59976e2e17155986de7d9fa` |
| `docs/phase_0_001/microtask_004_unit_scalars.md` | 3495 | `52a4ce20c740e51d1ead73e10cfd270ba1b40b629e55766325f333cc1a600850` |
| `docs/phase_0_001/microtask_005_constants_source_registry.md` | 3594 | `44530c0d220db3ab9478d9ec5b4f2defa42e7f6bab09a89f5e3f7ac8c851ff43` |
| `docs/phase_0_001/microtask_006_codex_card_schema_validation.md` | 4259 | `9482212c1d41e1b9970208a81afc17a132093a8204935eb3c002a7a0d1873a50` |
| `docs/phase_0_001/microtask_007_atmosphere_equations.md` | 3974 | `a2a6b3532725b2075d22b7b7cc331f9c5ba6abd07d53d0974b0022f077a85f37` |
| `docs/phase_0_001/microtask_008_thermodynamics_perfect_gas.md` | 3929 | `a6db0b65261ce75e539acd24c246375adc6e8a6377d4c52dacdf0eea16bf2c66` |
| `docs/phase_0_001/microtask_009_gas_dynamics_isentropic.md` | 3193 | `744fe992846ab7ab734744ff8aeb10e380875d9fdadb508ada9fe0cc95b837da` |
| `docs/phase_0_001/microtask_010_gas_dynamics_normal_shock.md` | 3203 | `c34c7c4926f32ea787b5a4b66d947545e683d2b5d50d0d3306555760fef12e4d` |
| `docs/phase_0_001/microtask_011_gas_dynamics_mach_angle_prandtl_meyer.md` | 3097 | `8cbec7752fd724952ad1313bbb8aed149e8eaca078f715d95d5dfa016a5dbbb4` |
| `docs/phase_0_001/microtask_012_gas_dynamics_oblique_shock.md` | 2291 | `153f6475310d137d9cfb9226d105196a252d213559af4e7bd5ac4bf4240293d2` |
| `docs/phase_0_001/microtask_013_aerodynamics_basic_coefficients.md` | 2761 | `92ada6d3a9afe269e4ee4f2dd0e0449957d798f48e454b565fb8e2083582e90c` |
| `docs/phase_0_001/microtask_014_propulsion_rocket_nozzle_basics.md` | 4412 | `2b91f046adb28b6395b54b1a09c2e561bfa514ecbf5b5dc8dc077350b2d1a215` |
| `docs/phase_0_001/microtask_015_heat_transfer.md` | 4672 | `09f5298c37d5467bd89c96ac78382a6cfbe08455975fe44c7ecb96752c98a93b` |
| `docs/phase_0_001/microtask_016_structures_beam_buckling.md` | 4668 | `d81ac24fed0b152371fd4d859c8cddef0e2aa1866e890ce564f650c0339f3911` |
| `docs/phase_0_001/microtask_017_flight_dynamics_basic_performance.md` | 4233 | `1ba478a5401dec489a5f5735fae9b5484971ad56cbf6bb764c4d7fbfdde1b75f` |
| `docs/phase_0_001/microtask_018_astrodynamics_two_body.md` | 4813 | `d7dd61fc50874990c6d0ac3af1c2bec386af486a8b9b4500a3ffeeb118600cee` |
| `docs/phase_0_001/microtask_019_astrodynamics_transfer_celestial.md` | 5229 | `4037ba790919bf44fce7c7b5bc4964e6fb09bed860d031e8b0534c004a65ea0f` |
| `docs/phase_0_001/microtask_020_bioregenerative_life_support.md` | 5483 | `73df205de89af62521eae4794fef844daf59623ff26b86da0e7608fbd229c754` |
| `docs/phase_0_001/microtask_log.md` | 65254 | `57f845bd0dfc542225c94bd0355aac449aca75645bcdd50e8919e15a8d3f97b2` |
| `docs/phase_0_001/source_research_backlog.md` | 20918 | `6038e363e10779282b837c30ae555b82bd69802f4bac792e9655886579fb2e6d` |
| `docs/phase_0_001/version_lock_audit.md` | 3196 | `09b2b9c5a5a01775b3087524626fce2f1ad5dcad09f9cb35a3f0bf88a86e39ad` |
| `docs/phase_0_001/working_inventory.md` | 2742 | `1202209a1a033b2f2920cf24ddb6b289e3fd5624f65c86dd6a3cfbacebdcfc3a` |
| `docs/roadmap/milestones.md` | 3317 | `b1e04cef7d0db848c5d4ece3a6e2a5049b6b72f23de0c8777f96af460e1850fd` |
| `docs/roadmap/post_1_0_expansion.md` | 2289 | `84bf34a17b4006048ce291caeeac6c0e8aa4e23928c9c154e016105cd4c1112a` |
| `docs/roadmap/versioning.md` | 4257 | `1dcbcc2fda64ad64b6c970c8ee8bbfe0eb11626557956d059c8f2af8e945e6dc` |
| `validation/README.md` | 3387 | `8d1ed98f3afac594e88d962a6c711a4fcee281a4736deb55d2b7b563903acfc4` |
| `validation/cards/aerodynamics_basic_coefficients.yaml` | 2662 | `0e1f6ffd40cd1b8967931a00dcd350ce5ab72cb97a6d16d60019c735280512d8` |
| `validation/cards/astrodynamics_transfer_celestial_basics.yaml` | 2916 | `60d6bc3419dfa04c9425e4b9582ef7e0de2179cd0d6cab54d16cee8c71472b35` |
| `validation/cards/astrodynamics_two_body_basics.yaml` | 2878 | `311924955099bf5663bef09a22c4576292116a0cd6d260ca06dc1fea3f124e24` |
| `validation/cards/atmosphere_standard_troposphere.yaml` | 1663 | `e718cb9a5bbf4ce1da53980b352ca42c59d69712526bf11762e8aa340fa961f0` |
| `validation/cards/examples/astrodynamics_two_body_vis_viva.yaml` | 788 | `109bd0bd75798a0a2ae17be970fc975c682600ae0481ce81072cb3ee6d20c45f` |
| `validation/cards/examples/gasdyn_isentropic_temperature_ratio.yaml` | 643 | `b8fbb651c06f8aa029ac95fddb080e6f2e739dd408ecee32f20d4cd34359ecd6` |
| `validation/cards/examples/life_support_bioregenerative_closure_fraction.yaml` | 1083 | `ef1abc58bc7b3996ce3176bc79d9ee8a0a43830fd320392d801e3d256f710980` |
| `validation/cards/flight_dynamics_basic_performance.yaml` | 2963 | `56547be36c4ba183e7ec060a0eba2f5e9e585adcab3d28e9c48c9065f06a272e` |
| `validation/cards/gasdyn_isentropic_flow.yaml` | 1591 | `8fe5b40f86739a4d73097228894b0016ba3fa8b7771e55d4ae3c64533bcb767a` |
| `validation/cards/gasdyn_mach_angle_prandtl_meyer.yaml` | 2154 | `9ac74a9c35a3f430a561c6a570f77f3c0116f675b88ba104da99f132dde8f610` |
| `validation/cards/gasdyn_normal_shock.yaml` | 1900 | `ebe9be0db6effc3c730d692d56f60da9cd8d852d37250d495fe86712af0ba535` |
| `validation/cards/gasdyn_oblique_shock.yaml` | 2344 | `deb1c1542ebeedeb1cc756313b6857f937ac3dfa361e9e49fc99e515a4a60148` |
| `validation/cards/heat_transfer_basic_primitives.yaml` | 2717 | `03114aa2d004ffabfda513df79228c0c8e367ec9847c22f6834cbeaee92e02ca` |
| `validation/cards/life_support_bioregenerative_mass_balance.yaml` | 2531 | `54a8b945db667fecdf41ba0ae8f3bf59048c170ae5d7bd029ff7b4d45edb2fe4` |
| `validation/cards/life_support_buffer_residence_time.yaml` | 989 | `ec3a4669e9f1461a385f897eca6a423b5077a9d2a4e4dfcb96a5387480aa07af` |
| `validation/cards/life_support_closure_fraction.yaml` | 1372 | `40ce566f01ebeb8a1c37454e8719889717086c99e6990fc2557027f0e862c9d2` |
| `validation/cards/life_support_daily_mass_balance.yaml` | 1847 | `c79189d12dd25cf4daf33fab210526ee6c57d6bcc929ffc93054ce46f1a929e8` |
| `validation/cards/life_support_required_production_area.yaml` | 1143 | `819b2261e43c41733b32c09be07115c7c22792d36341288e03267af50b046693` |
| `validation/cards/propulsion_rocket_nozzle_basics.yaml` | 3138 | `d9ef23f9a951169ba5ac4f35bf5ab226b7fce44eaa2d0b0888ce1206453dc66a` |
| `validation/cards/structures_beam_buckling_basics.yaml` | 2682 | `3b2788c43fe76b494dedafc91ffd69e9f19a2a4bac07f912e7d8284e83a3d569` |
| `validation/cards/thermo_perfect_gas.yaml` | 2402 | `3b068c9fdc544cae18b275ccc58a8fd42a77de3b0fd6d304481d2ce2591dcc91` |
| `validation/schema/codex_card.schema.json` | 4139 | `e2cf5f99328a91e23eeef4652a5f7255808c5056e83655b87b5ccbbd5c2f44c8` |
| `validation/source_registry/aerodynamics_basic_coefficients.yaml` | 1636 | `14b8073da8bf0ca75fe6bc7d72f8857510ef20bbffd8167572744f794d0ff101` |
| `validation/source_registry/astrodynamics_transfer_celestial_basics.yaml` | 2327 | `4129d8cc9f8bb3ec6a9a31a7bd9bc489f7265aef6f3ae253fa4729a2e66086bb` |
| `validation/source_registry/astrodynamics_two_body_basics.yaml` | 1807 | `0849996b41ad5f846ac2d20f5dcd2ad4cd98dd5aefed0933b062d9cd44fa1d83` |
| `validation/source_registry/flight_dynamics_basic_performance.yaml` | 1674 | `ec1116c1876ce02764894d8105696818e1640e3b0ea60dce0e3b45548145fb80` |
| `validation/source_registry/heat_transfer_basic_primitives.yaml` | 1687 | `ebda905d9a012cb830616a5b1e21529335dcfcff9a43b30dab1b1994ae17945a` |
| `validation/source_registry/life_support_bioregenerative_mass_balance.yaml` | 1617 | `d787e4cdf2c8c3515f9cc7c6089e5bdc4ede03cb0e74eb2d597a05d7bbfd5d64` |
| `validation/source_registry/naca_report_1135.yaml` | 2476 | `d0bf9a9922951b914ebf9b8bbf911b37fbd24aaef06e236d104feee9b4fe7a02` |
| `validation/source_registry/nasa_glenn_thermo_cea.yaml` | 1439 | `7bd2b2f2e166c3ace4f167f3d1809ddf1630c8114bcfd5240e34266afb67a8b7` |
| `validation/source_registry/nasa_jpl_astrodynamics_parameters.yaml` | 1718 | `a0b9e2b47ea3f669f15f7d5fd63fdd1eff583ca40544866af0e723dd0f108bec` |
| `validation/source_registry/nasa_life_support_bvad_eclss.yaml` | 1892 | `3c0f6229c4c57a8b94468a7ec709ae848608a66c714da6bf078d682c1c1eae97` |
| `validation/source_registry/nist_codata_physical_constants.yaml` | 940 | `e2c399eadcfb7c51fca4fde1d1d2c1dab92f41bce27605041032376009074338` |
| `validation/source_registry/propulsion_rocket_nozzle_basics.yaml` | 1609 | `faf715549c24a00228b1f0c12a477752d22c96506b3f6fcbb9aa9b991036196c` |
| `validation/source_registry/structures_basic_mechanics.yaml` | 1515 | `859849289c5d3c8a700332827129b364ac96ec7a1502c3cd394932e80bd5e7f8` |
| `validation/source_registry/us_standard_atmosphere_1976.yaml` | 938 | `3caf023a109502d00bff12a7d5e675e86aedab2a53d24aae7809c3c266b7f401` |
| `xtask/Cargo.toml` | 245 | `50a347879fbfe208718f7949fbc8f75cb1b56a257aa3c03ec349d4e914dba84a` |
| `xtask/src/main.rs` | 17909 | `a702fb1e8bf5d94428399fc150b5df21049f6d942ca0f71c4bd91d96ef42242b` |
